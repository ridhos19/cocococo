#pragma once

// DATA: batas baku mutu (nilai contoh, sesuaikan dengan peruntukan reuse)
struct BakuMutu {
    double pHMin = 6.0;
    double pHMax = 9.0;
    double kekeruhanMaks = 5.0;  // NTU
    double CODMaks = 50.0;       // mg/L
};
