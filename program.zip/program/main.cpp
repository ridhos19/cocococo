#include <iostream>
#include <vector>
#include <string>
#include <limits>
#include <ctime>
#include <iomanip>
#include "sensor.hpp"
#include "baku_mutu.hpp"
using namespace std;

// ABSTRAKSI -> Struktur Data
vector<DataSensor> riwayat;
BakuMutu baku;

// ---------- fungsi bantu ----------
string WaktuSekarang() {
    time_t t = time(nullptr);
    char buf[20];
    strftime(buf, sizeof(buf), "%d-%m-%Y %H:%M", localtime(&t));
    return buf;
}

// Semi otomatis: evaluasi & peringatan dijalankan program,
// tindakan fisik (mengalirkan air) dilakukan operator.

// Pola penanganan error: baca angka, ulangi jika bukan angka
bool BacaAngka(const string& label, double& nilai) {
    cout << label;
    if (!(cin >> nilai)) {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        return false;
    }
    return true;
}

// ---------- fungsi utama (hasil Dekomposisi) ----------
void BacaDataSensor() {
    DataSensor d;
    bool valid;
    do {                                            // Do ... while (flowchart)
        valid = BacaAngka("Input pH           : ", d.pH)
            && BacaAngka("Input kekeruhan(NTU): ", d.kekeruhan)
            && BacaAngka("Input COD (mg/L)    : ", d.COD)
            && d.pH >= 0 && d.kekeruhan >= 0 && d.COD >= 0;
        if (!valid) cout << "Data sensor tidak valid, ulangi pembacaan.\n";
    } while (!valid);

    d.waktu = WaktuSekarang();
    d.status = "-";
    riwayat.push_back(d);                           // riwayat.push_back(d)
    cout << "Data sensor tersimpan.\n";
}

void EvaluasiKualitas() {
    if (riwayat.empty()) {                          // riwayat.empty()?
        cout << "Belum ada data sensor.\n";
        return;
    }
    DataSensor& d = riwayat.back();                 // data terbaru
    bool layak = d.pH >= baku.pHMin && d.pH <= baku.pHMax
            && d.kekeruhan <= baku.kekeruhanMaks
            && d.COD <= baku.CODMaks;

    if (layak) {
        d.status = "Layak Reuse";   // peruntukan: non-konsumsi (tidak untuk diminum)
        cout << "Status: " << d.status
            << " -> air dapat dialirkan operator ke tangki reuse.\n";
    } else {
        d.status = "Perlu Olah Ulang";
        cout << "Status: " << d.status << "\n"
            << "Peringatan ke operator: air belum memenuhi baku mutu, "
                "perlu diolah ulang.\n";
    }
}

void TampilkanRiwayat() {
    if (riwayat.empty()) {
        cout << "Belum ada data.\n";
        return;
    }
    cout << left << setw(18) << "Waktu" << setw(6) << "pH"
        << setw(12) << "Kekeruhan" << setw(8) << "COD" << "Status\n";
    for (const auto& d : riwayat) {                 // for (const auto& d : riwayat)
        cout << left << setw(18) << d.waktu << setw(6) << d.pH
            << setw(12) << d.kekeruhan << setw(8) << d.COD << d.status << "\n";
    }
}

// ---------- Entry Point ----------
void MenuUtama() {
    int pilihan;
    do {
        cout << "\n=== Monitoring Air Limbah ===\n"
                "1. Baca Data Sensor\n2. Evaluasi Kualitas Air\n"
                "3. Riwayat Data\n4. Keluar\nPilihan: ";
        if (!(cin >> pilihan) || pilihan < 1 || pilihan > 4) {   // input valid?
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Inputan tidak valid\n";
            pilihan = 0;
            continue;
        }
        switch (pilihan) {
            case 1: BacaDataSensor();   break;
            case 2: EvaluasiKualitas(); break;
            case 3: TampilkanRiwayat(); break;
            case 4: cout << "Keluar.\n"; break;
        }
    } while (pilihan != 4);
}

int main() {
    MenuUtama();
    return 0;
}
