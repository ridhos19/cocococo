#pragma once
#include <string>

// DATA (Dekomposisi -> Data): satu hasil pembacaan sensor
struct DataSensor {
    double pH;
    double kekeruhan;   // NTU
    double COD;         // mg/L
    std::string waktu;
    std::string status; // "Layak Reuse" (non-konsumsi) / "Perlu Olah Ulang"
};
